(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/Site.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BudgetPlanner",
    ()=>BudgetPlanner,
    "EnquiryForm",
    ()=>EnquiryForm,
    "Footer",
    ()=>Footer,
    "Header",
    ()=>Header,
    "ImageBox",
    ()=>ImageBox,
    "Shell",
    ()=>Shell,
    "VenueCard",
    ()=>VenueCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$image$2d$component$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Image__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/image-component.js [app-client] (ecmascript) <export Image as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data/site.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function Brand({ footer = false }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        className: footer ? 'brand brand-footer' : 'brand',
        href: "/",
        "aria-label": "Weddings Vibe home",
        children: footer ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$image$2d$component$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Image__as__default$3e$__["default"], {
            src: "/images/logo.png",
            alt: "Weddings Vibe",
            width: 360,
            height: 360
        }, void 0, false, {
            fileName: "[project]/src/components/Site.js",
            lineNumber: 7,
            columnNumber: 142
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$image$2d$component$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Image__as__default$3e$__["default"], {
                    src: "/images/logo-icon.png",
                    alt: "",
                    width: 54,
                    height: 54
                }, void 0, false, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 7,
                    columnNumber: 221
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    children: "WEDDINGS VIBE"
                }, void 0, false, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 7,
                    columnNumber: 287
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Site.js",
            lineNumber: 7,
            columnNumber: 219
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Site.js",
        lineNumber: 7,
        columnNumber: 39
    }, this);
}
_c = Brand;
function Header() {
    _s();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: "header",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "wrap navrow",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Brand, {}, void 0, false, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 8,
                    columnNumber: 126
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    className: "hamb",
                    "aria-label": open ? 'Close menu' : 'Open menu',
                    "aria-expanded": open,
                    onClick: ()=>setOpen(!open),
                    children: open ? '×' : '☰'
                }, void 0, false, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 8,
                    columnNumber: 134
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                    className: open ? 'nav open' : 'nav',
                    children: [
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["site"].nav.map((n)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: n.label === 'Venues' ? 'dd' : '',
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: n.href,
                                        children: [
                                            n.label,
                                            n.label === 'Venues' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                children: "⌄"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Site.js",
                                                lineNumber: 8,
                                                columnNumber: 438
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Site.js",
                                        lineNumber: 8,
                                        columnNumber: 388
                                    }, this),
                                    n.label === 'Venues' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mega",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "wrap",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mbox",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                        className: "cities",
                                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cities"].map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                className: "city",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                        href: `/wedding-venues-in-${c.slug}`,
                                                                        children: [
                                                                            c.name,
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                                                children: [
                                                                                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["venues"].filter((v)=>v.city === c.name).length,
                                                                                    " venues"
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/components/Site.js",
                                                                                lineNumber: 8,
                                                                                columnNumber: 673
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/components/Site.js",
                                                                        lineNumber: 8,
                                                                        columnNumber: 621
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "cp",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                className: "chd",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                                        children: [
                                                                                            "Wedding venues in ",
                                                                                            c.name
                                                                                        ]
                                                                                    }, void 0, true, {
                                                                                        fileName: "[project]/src/components/Site.js",
                                                                                        lineNumber: 8,
                                                                                        columnNumber: 785
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                                        className: "underline",
                                                                                        href: `/wedding-venues-in-${c.slug}`,
                                                                                        children: "View all"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/components/Site.js",
                                                                                        lineNumber: 8,
                                                                                        columnNumber: 820
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/components/Site.js",
                                                                                lineNumber: 8,
                                                                                columnNumber: 764
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                className: "vg",
                                                                                children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["venues"].filter((v)=>v.city === c.name).slice(0, 3).map((v)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                                        className: "vc",
                                                                                        href: `/venues/${v.citySlug}/${v.slug}`,
                                                                                        children: [
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                                className: `ph ${v.images[0].replace('.svg', '')}`,
                                                                                                style: {
                                                                                                    height: 110,
                                                                                                    borderRadius: 12
                                                                                                }
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/src/components/Site.js",
                                                                                                lineNumber: 8,
                                                                                                columnNumber: 1055
                                                                                            }, this),
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                                                children: v.name
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/src/components/Site.js",
                                                                                                lineNumber: 8,
                                                                                                columnNumber: 1149
                                                                                            }, this),
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                                                                children: [
                                                                                                    v.area,
                                                                                                    " · ₹",
                                                                                                    v.pricePerPlate.toLocaleString('en-IN'),
                                                                                                    "/plate"
                                                                                                ]
                                                                                            }, void 0, true, {
                                                                                                fileName: "[project]/src/components/Site.js",
                                                                                                lineNumber: 8,
                                                                                                columnNumber: 1174
                                                                                            }, this)
                                                                                        ]
                                                                                    }, v.slug, true, {
                                                                                        fileName: "[project]/src/components/Site.js",
                                                                                        lineNumber: 8,
                                                                                        columnNumber: 980
                                                                                    }, this))
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/components/Site.js",
                                                                                lineNumber: 8,
                                                                                columnNumber: 907
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/components/Site.js",
                                                                        lineNumber: 8,
                                                                        columnNumber: 744
                                                                    }, this)
                                                                ]
                                                            }, c.slug, true, {
                                                                fileName: "[project]/src/components/Site.js",
                                                                lineNumber: 8,
                                                                columnNumber: 587
                                                            }, this))
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Site.js",
                                                        lineNumber: 8,
                                                        columnNumber: 549
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "mfoot",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: "Browse by type"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/Site.js",
                                                                lineNumber: 8,
                                                                columnNumber: 1304
                                                            }, this),
                                                            [
                                                                'Banquet halls',
                                                                'Resorts',
                                                                'Farmhouses',
                                                                'Palaces',
                                                                'Beach venues'
                                                            ].map((x)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                    className: "chip",
                                                                    href: "/venues",
                                                                    children: x
                                                                }, x, false, {
                                                                    fileName: "[project]/src/components/Site.js",
                                                                    lineNumber: 8,
                                                                    columnNumber: 1405
                                                                }, this))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/Site.js",
                                                        lineNumber: 8,
                                                        columnNumber: 1281
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/Site.js",
                                                lineNumber: 8,
                                                columnNumber: 527
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Site.js",
                                            lineNumber: 8,
                                            columnNumber: 505
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Site.js",
                                        lineNumber: 8,
                                        columnNumber: 483
                                    }, this)
                                ]
                            }, n.href, true, {
                                fileName: "[project]/src/components/Site.js",
                                lineNumber: 8,
                                columnNumber: 331
                            }, this)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mobile-cities",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                        children: "Browse venues by city"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Site.js",
                                        lineNumber: 8,
                                        columnNumber: 1536
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "chips",
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cities"].map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                className: "chip",
                                                href: `/wedding-venues-in-${c.slug}`,
                                                children: c.name
                                            }, c.slug, false, {
                                                fileName: "[project]/src/components/Site.js",
                                                lineNumber: 8,
                                                columnNumber: 1614
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Site.js",
                                        lineNumber: 8,
                                        columnNumber: 1576
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Site.js",
                                lineNumber: 8,
                                columnNumber: 1527
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Site.js",
                            lineNumber: 8,
                            columnNumber: 1496
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 8,
                    columnNumber: 275
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    className: "btn plan",
                    href: "/contact",
                    children: "Plan my wedding"
                }, void 0, false, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 8,
                    columnNumber: 1733
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Site.js",
            lineNumber: 8,
            columnNumber: 97
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Site.js",
        lineNumber: 8,
        columnNumber: 70
    }, this);
}
_s(Header, "6dOGeNFz7lEsAiwKPNBpp5+ZTyc=");
_c1 = Header;
function SocialIcon({ type }) {
    if (type === 'Instagram') return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        viewBox: "0 0 24 24",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                x: "3",
                y: "3",
                width: "18",
                height: "18",
                rx: "5"
            }, void 0, false, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 9,
                columnNumber: 83
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "12",
                cy: "12",
                r: "4"
            }, void 0, false, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 9,
                columnNumber: 132
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "17.2",
                cy: "6.8",
                r: "1",
                fill: "currentColor"
            }, void 0, false, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 9,
                columnNumber: 163
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Site.js",
        lineNumber: 9,
        columnNumber: 58
    }, this);
    if (type === 'LinkedIn') return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        viewBox: "0 0 24 24",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            fill: "currentColor",
            stroke: "none",
            d: "M4 9h3v11H4zM5.5 4a1.8 1.8 0 1 0 0 3.6 1.8 1.8 0 0 0 0-3.6zM10 9h3v1.6c.5-1 1.7-1.9 3.3-1.9 3 0 3.7 2 3.7 4.6V20h-3v-5.8c0-1.4-.1-2.7-1.8-2.7s-2 1.2-2 2.6V20h-3z"
        }, void 0, false, {
            fileName: "[project]/src/components/Site.js",
            lineNumber: 9,
            columnNumber: 277
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Site.js",
        lineNumber: 9,
        columnNumber: 252
    }, this);
    if (type === 'YouTube') return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        viewBox: "0 0 24 24",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                x: "2",
                y: "5",
                width: "20",
                height: "14",
                rx: "4"
            }, void 0, false, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 9,
                columnNumber: 543
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fill: "currentColor",
                stroke: "none",
                d: "m10 9 5 3-5 3z"
            }, void 0, false, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 9,
                columnNumber: 592
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Site.js",
        lineNumber: 9,
        columnNumber: 518
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        viewBox: "0 0 24 24",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "12",
                cy: "12",
                r: "9"
            }, void 0, false, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 9,
                columnNumber: 691
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "m11 17 1.5-6.5m-2.5 3c-.5-2.5 1-4.5 3-4.5 1.8 0 2.8 1.3 2.5 3s-1.4 2.8-2.8 2.5"
            }, void 0, false, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 9,
                columnNumber: 722
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Site.js",
        lineNumber: 9,
        columnNumber: 666
    }, this);
}
_c2 = SocialIcon;
function Footer() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: "ft",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "wrap",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "footer-grid",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Brand, {
                                    footer: true
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Site.js",
                                    lineNumber: 10,
                                    columnNumber: 112
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["site"].tagline
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Site.js",
                                    lineNumber: 10,
                                    columnNumber: 127
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Site.js",
                            lineNumber: 10,
                            columnNumber: 107
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                    children: "Contact"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Site.js",
                                    lineNumber: 10,
                                    columnNumber: 159
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["site"].address
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Site.js",
                                    lineNumber: 10,
                                    columnNumber: 175
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "ft-links",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: `tel:${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["site"].phoneLink}`,
                                            children: [
                                                "Call: ",
                                                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["site"].phone
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/Site.js",
                                            lineNumber: 10,
                                            columnNumber: 222
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: `mailto:${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["site"].email}`,
                                            children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["site"].email
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Site.js",
                                            lineNumber: 10,
                                            columnNumber: 278
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: "https://maps.google.com/?q=12+Sample+Road+New+Delhi",
                                            children: "Get directions"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Site.js",
                                            lineNumber: 10,
                                            columnNumber: 327
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Site.js",
                                    lineNumber: 10,
                                    columnNumber: 196
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "hours",
                                    children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["site"].hours
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Site.js",
                                    lineNumber: 10,
                                    columnNumber: 413
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Site.js",
                            lineNumber: 10,
                            columnNumber: 154
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "qr",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "qrbox",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "W"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Site.js",
                                            lineNumber: 10,
                                            columnNumber: 504
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Site.js",
                                        lineNumber: 10,
                                        columnNumber: 481
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: "Scan to follow us on Instagram"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Site.js",
                                        lineNumber: 10,
                                        columnNumber: 524
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["site"].instagram
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Site.js",
                                        lineNumber: 10,
                                        columnNumber: 565
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Site.js",
                                lineNumber: 10,
                                columnNumber: 461
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Site.js",
                            lineNumber: 10,
                            columnNumber: 456
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                    children: "Follow us"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Site.js",
                                    lineNumber: 10,
                                    columnNumber: 615
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "soc",
                                    children: Object.entries(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["site"].socials).map(([name, url])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: url,
                                            "aria-label": name,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SocialIcon, {
                                                type: name === 'instagram' ? 'Instagram' : name === 'linkedin' ? 'LinkedIn' : name === 'youtube' ? 'YouTube' : 'Pinterest'
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Site.js",
                                                lineNumber: 10,
                                                columnNumber: 745
                                            }, this)
                                        }, name, false, {
                                            fileName: "[project]/src/components/Site.js",
                                            lineNumber: 10,
                                            columnNumber: 702
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Site.js",
                                    lineNumber: 10,
                                    columnNumber: 633
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    className: "btn",
                                    href: `https://wa.me/${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["site"].whatsapp}`,
                                    children: "Chat on WhatsApp"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Site.js",
                                    lineNumber: 10,
                                    columnNumber: 876
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Site.js",
                            lineNumber: 10,
                            columnNumber: 610
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 10,
                    columnNumber: 78
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "foot-bottom",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: [
                                "© 2026 Weddings Vibe. All rights reserved. · ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/privacy-policy",
                                    children: "Privacy"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Site.js",
                                    lineNumber: 10,
                                    columnNumber: 1047
                                }, this),
                                " · ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/terms",
                                    children: "Terms"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Site.js",
                                    lineNumber: 10,
                                    columnNumber: 1093
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Site.js",
                            lineNumber: 10,
                            columnNumber: 996
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            className: "totop",
                            href: "#top",
                            "aria-label": "Back to top",
                            children: "↑"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Site.js",
                            lineNumber: 10,
                            columnNumber: 1132
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 10,
                    columnNumber: 967
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Site.js",
            lineNumber: 10,
            columnNumber: 56
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Site.js",
        lineNumber: 10,
        columnNumber: 33
    }, this);
}
_c3 = Footer;
function Shell({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Header, {}, void 0, false, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 11,
                columnNumber: 44
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 11,
                columnNumber: 53
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Footer, {}, void 0, false, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 11,
                columnNumber: 76
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                className: "wa-float",
                "aria-label": "Chat on WhatsApp",
                href: `https://wa.me/${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["site"].whatsapp}`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 24 24",
                    "aria-hidden": "true",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M20 11.5a8 8 0 0 1-11.8 7L4 20l1.5-4A8 8 0 1 1 20 11.5Z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Site.js",
                            lineNumber: 11,
                            columnNumber: 223
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M9 8.5c.3 2.6 2 4.4 4.7 5.2l1.1-1.1 2 .9c-.2 1.2-1.2 1.8-2.4 1.7-3.6-.4-6.7-3.4-7-6.8-.1-1.2.5-2.2 1.5-2.4l1 2z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Site.js",
                            lineNumber: 11,
                            columnNumber: 290
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 11,
                    columnNumber: 179
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 11,
                columnNumber: 85
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Site.js",
        lineNumber: 11,
        columnNumber: 42
    }, this);
}
_c4 = Shell;
function ImageBox({ image = 'im1.svg', className = '', alt = '' }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        role: "img",
        "aria-label": alt,
        className: `ph ${image.replace('.svg', '')} ${className}`
    }, void 0, false, {
        fileName: "[project]/src/components/Site.js",
        lineNumber: 12,
        columnNumber: 72
    }, this);
}
_c5 = ImageBox;
function VenueCard({ venue }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: `/venues/${venue.citySlug}/${venue.slug}`,
        className: "card",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ImageBox, {
                image: venue.images[0],
                alt: venue.name
            }, void 0, false, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 13,
                columnNumber: 115
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "cardbody",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "rating",
                        children: [
                            "★ ",
                            venue.rating,
                            " ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    "(",
                                    venue.reviewCount,
                                    " reviews)"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Site.js",
                                lineNumber: 13,
                                columnNumber: 234
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Site.js",
                        lineNumber: 13,
                        columnNumber: 193
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        children: venue.name
                    }, void 0, false, {
                        fileName: "[project]/src/components/Site.js",
                        lineNumber: 13,
                        columnNumber: 282
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            venue.area,
                            ", ",
                            venue.city,
                            " · ",
                            venue.capacity.max,
                            " guests"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Site.js",
                        lineNumber: 13,
                        columnNumber: 303
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                        children: [
                            "₹",
                            venue.pricePerPlate.toLocaleString('en-IN'),
                            " ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                children: "/ plate"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Site.js",
                                lineNumber: 13,
                                columnNumber: 421
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Site.js",
                        lineNumber: 13,
                        columnNumber: 366
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 13,
                columnNumber: 167
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Site.js",
        lineNumber: 13,
        columnNumber: 43
    }, this);
}
_c6 = VenueCard;
function EnquiryForm({ type = 'contact', subject = '', slug = '', compact = false }) {
    _s1();
    const [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    async function submit(e) {
        e.preventDefault();
        const form = e.currentTarget;
        setStatus('Sending your enquiry…');
        const data = Object.fromEntries(new FormData(form));
        try {
            if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL) {
                const r = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL}/api/enquiry`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        ...data,
                        type,
                        subject,
                        slug
                    })
                });
                if (!r.ok) throw Error('Please try again in a moment.');
            }
            setStatus('Thank you! A wedding planner will be in touch shortly.');
            form.reset();
        } catch  {
            setStatus('We could not send that just now. Please call us at +91 00000 00000.');
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        className: `form ${compact ? 'compact' : ''}`,
        onSubmit: submit,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                children: subject || 'Tell us about your wedding'
            }, void 0, false, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 14,
                columnNumber: 790
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                children: [
                    "Your name",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        name: "name",
                        required: true,
                        autoComplete: "name"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Site.js",
                        lineNumber: 14,
                        columnNumber: 854
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 14,
                columnNumber: 838
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                children: [
                    "Phone number",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        name: "phone",
                        type: "tel",
                        required: true,
                        autoComplete: "tel",
                        pattern: "[+0-9 ()-]{8,}"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Site.js",
                        lineNumber: 14,
                        columnNumber: 930
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 14,
                columnNumber: 911
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                children: [
                    "Email address",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        name: "email",
                        type: "email",
                        autoComplete: "email"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Site.js",
                        lineNumber: 14,
                        columnNumber: 1043
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 14,
                columnNumber: 1023
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                children: [
                    "City",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        name: "city",
                        defaultValue: "",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "Choose a city"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Site.js",
                                lineNumber: 14,
                                columnNumber: 1153
                            }, this),
                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cities"].map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    children: c.name
                                }, c.slug, false, {
                                    fileName: "[project]/src/components/Site.js",
                                    lineNumber: 14,
                                    columnNumber: 1207
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Site.js",
                        lineNumber: 14,
                        columnNumber: 1117
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 14,
                columnNumber: 1106
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                children: [
                    "Wedding date",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        name: "date",
                        type: "date"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Site.js",
                        lineNumber: 14,
                        columnNumber: 1283
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 14,
                columnNumber: 1264
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                children: [
                    "Guest count",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        name: "guests",
                        type: "number",
                        min: "1"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Site.js",
                        lineNumber: 14,
                        columnNumber: 1341
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 14,
                columnNumber: 1323
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                className: "trap",
                children: [
                    "Website",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        name: "website",
                        tabIndex: "-1",
                        autoComplete: "off"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Site.js",
                        lineNumber: 14,
                        columnNumber: 1424
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 14,
                columnNumber: 1393
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                children: [
                    "Tell us a little more",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        name: "message",
                        rows: "3"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Site.js",
                        lineNumber: 14,
                        columnNumber: 1516
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 14,
                columnNumber: 1488
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: "btn",
                disabled: status.startsWith('Sending'),
                children: "Send enquiry"
            }, void 0, false, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 14,
                columnNumber: 1559
            }, this),
            status && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "status",
                children: status
            }, void 0, false, {
                fileName: "[project]/src/components/Site.js",
                lineNumber: 14,
                columnNumber: 1653
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Site.js",
        lineNumber: 14,
        columnNumber: 723
    }, this);
}
_s1(EnquiryForm, "/aXvP+72PAdPq+XKKH2yT3tKB6s=");
_c7 = EnquiryForm;
function BudgetPlanner() {
    _s2();
    const [step, setStep] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false), [done, setDone] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false), [plan, setPlan] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        guests: '150',
        budget: '',
        city: 'Delhi'
    }), [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    async function send(e) {
        e.preventDefault();
        const form = e.currentTarget;
        const data = {
            ...Object.fromEntries(new FormData(form)),
            ...plan
        };
        setStatus('Sending your plan…');
        try {
            if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL) {
                const r = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL}/api/enquiry`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        ...data,
                        type: 'budget-planner'
                    })
                });
                if (!r.ok) throw Error();
            }
            setDone(true);
        } catch  {
            setStatus('We could not send that now. Please call us at +91 00000 00000.');
        }
    }
    const total = Number(plan.budget) || 0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "budget-panel",
        children: done ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    children: "Your celebration, thoughtfully divided"
                }, void 0, false, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 15,
                    columnNumber: 783
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "budget-split",
                    children: [
                        [
                            'Food',
                            40
                        ],
                        [
                            'Decor',
                            30
                        ],
                        [
                            'Photography',
                            20
                        ],
                        [
                            'Flex fund',
                            10
                        ]
                    ].map(([label, share])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: [
                                label,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: total ? `₹${Math.round(total * share / 100).toLocaleString('en-IN')}` : `${share}%`
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Site.js",
                                    lineNumber: 15,
                                    columnNumber: 967
                                }, this)
                            ]
                        }, label, true, {
                            fileName: "[project]/src/components/Site.js",
                            lineNumber: 15,
                            columnNumber: 945
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 15,
                    columnNumber: 830
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: [
                        plan.city,
                        " · ",
                        Number(plan.guests).toLocaleString('en-IN'),
                        " guests"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 15,
                    columnNumber: 1073
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "We’ll be in touch to tailor this plan to your day."
                }, void 0, false, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 15,
                    columnNumber: 1146
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Site.js",
            lineNumber: 15,
            columnNumber: 781
        }, this) : step ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            className: "form",
            onSubmit: send,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    children: "Where can we send your plan?"
                }, void 0, false, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 15,
                    columnNumber: 1251
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    children: [
                        "Your name",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            name: "name",
                            required: true,
                            autoComplete: "name"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Site.js",
                            lineNumber: 15,
                            columnNumber: 1304
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 15,
                    columnNumber: 1288
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    children: [
                        "Phone number",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            name: "phone",
                            required: true,
                            type: "tel",
                            pattern: "[+0-9 ()-]{8,}",
                            autoComplete: "tel"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Site.js",
                            lineNumber: 15,
                            columnNumber: 1380
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 15,
                    columnNumber: 1361
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    children: [
                        "Email address",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            name: "email",
                            type: "email"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Site.js",
                            lineNumber: 15,
                            columnNumber: 1493
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 15,
                    columnNumber: 1473
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "trap",
                    children: [
                        "Website",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            name: "website",
                            tabIndex: "-1"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Site.js",
                            lineNumber: 15,
                            columnNumber: 1566
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 15,
                    columnNumber: 1535
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    className: "btn",
                    children: "Get my plan"
                }, void 0, false, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 15,
                    columnNumber: 1611
                }, this),
                status && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "status",
                    children: status
                }, void 0, false, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 15,
                    columnNumber: 1664
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Site.js",
            lineNumber: 15,
            columnNumber: 1212
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            className: "budget-form",
            onSubmit: (e)=>{
                e.preventDefault();
                setStep(true);
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    children: [
                        "Guests",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "number",
                            min: "1",
                            required: true,
                            value: plan.guests,
                            onChange: (e)=>setPlan({
                                    ...plan,
                                    guests: e.target.value
                                })
                        }, void 0, false, {
                            fileName: "[project]/src/components/Site.js",
                            lineNumber: 15,
                            columnNumber: 1794
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 15,
                    columnNumber: 1781
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    children: [
                        "Budget",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "number",
                            min: "1",
                            required: true,
                            placeholder: "₹",
                            value: plan.budget,
                            onChange: (e)=>setPlan({
                                    ...plan,
                                    budget: e.target.value
                                })
                        }, void 0, false, {
                            fileName: "[project]/src/components/Site.js",
                            lineNumber: 15,
                            columnNumber: 1929
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 15,
                    columnNumber: 1916
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    children: [
                        "City",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                            value: plan.city,
                            onChange: (e)=>setPlan({
                                    ...plan,
                                    city: e.target.value
                                }),
                            children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cities"].map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    children: c.name
                                }, c.slug, false, {
                                    fileName: "[project]/src/components/Site.js",
                                    lineNumber: 15,
                                    columnNumber: 2172
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/components/Site.js",
                            lineNumber: 15,
                            columnNumber: 2078
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 15,
                    columnNumber: 2067
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    className: "btn",
                    children: "Show my plan"
                }, void 0, false, {
                    fileName: "[project]/src/components/Site.js",
                    lineNumber: 15,
                    columnNumber: 2229
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Site.js",
            lineNumber: 15,
            columnNumber: 1702
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Site.js",
        lineNumber: 15,
        columnNumber: 745
    }, this);
}
_s2(BudgetPlanner, "uAIEes+MbK7NUTw836TCR6ZesO4=");
_c8 = BudgetPlanner;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8;
__turbopack_context__.k.register(_c, "Brand");
__turbopack_context__.k.register(_c1, "Header");
__turbopack_context__.k.register(_c2, "SocialIcon");
__turbopack_context__.k.register(_c3, "Footer");
__turbopack_context__.k.register(_c4, "Shell");
__turbopack_context__.k.register(_c5, "ImageBox");
__turbopack_context__.k.register(_c6, "VenueCard");
__turbopack_context__.k.register(_c7, "EnquiryForm");
__turbopack_context__.k.register(_c8, "BudgetPlanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/data/site.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cities",
    ()=>cities,
    "faqs",
    ()=>faqs,
    "posts",
    ()=>posts,
    "services",
    ()=>services,
    "site",
    ()=>site,
    "testimonials",
    ()=>testimonials,
    "venues",
    ()=>venues,
    "weddings",
    ()=>weddings
]);
const site = {
    name: 'Weddings Vibe',
    tagline: 'Wedding venues and services, one enquiry away.',
    address: '12 Sample Road, New Delhi - 110001',
    phone: '+91 00000 00000',
    phoneLink: '+910000000000',
    whatsapp: '910000000000',
    email: 'hello@weddingsvibe.com',
    instagram: '@weddingsvibe',
    socials: {
        instagram: 'https://instagram.com/weddingsvibe',
        linkedin: 'https://linkedin.com',
        youtube: 'https://youtube.com',
        pinterest: 'https://pinterest.com'
    },
    hours: 'Monday to Saturday, 10 am – 7 pm',
    nav: [
        {
            label: 'Venues',
            href: '/venues'
        },
        {
            label: 'Services',
            href: '/services'
        },
        {
            label: 'Real Weddings',
            href: '/real-weddings'
        },
        {
            label: 'Blog',
            href: '/blog'
        },
        {
            label: 'Contact',
            href: '/contact'
        }
    ]
};
const cityInfo = [
    [
        'Bengaluru',
        'Indiranagar',
        'Whitefield',
        'J.P. Nagar'
    ],
    [
        'Delhi',
        'Dwarka',
        'Saket',
        'Chattarpur'
    ],
    [
        'Mumbai',
        'Bandra',
        'Powai',
        'Andheri'
    ],
    [
        'Goa',
        'Candolim',
        'Assagao',
        'Vagator'
    ],
    [
        'Noida',
        'Sector 18',
        'Sector 62',
        'Greater Noida'
    ],
    [
        'Gurugram',
        'Golf Course Road',
        'Sohna Road',
        'Manesar'
    ],
    [
        'Jaipur',
        'Amer Road',
        'Tonk Road',
        'Civil Lines'
    ],
    [
        'Udaipur',
        'Lake Pichola',
        'Fateh Sagar',
        'Hiran Magri'
    ]
];
const cities = cityInfo.map(([name, ...areas], i)=>({
        name,
        slug: name.toLowerCase().replaceAll(' ', '-'),
        areas,
        landmark: [
            'Vidhana Soudha',
            'India Gate',
            'Gateway of India',
            'Fort Aguada',
            'Okhla Bird Sanctuary',
            'Kingdom of Dreams',
            'Hawa Mahal',
            'City Palace'
        ][i]
    }));
const venueNames = [
    'The Grand Pavilion',
    'Ivory Courtyard',
    'Gardenia Estate'
];
const venueTypes = [
    'banquet',
    'palace',
    'farmhouse',
    'resort',
    'beach',
    'destination'
];
const venues = cities.flatMap((city, ci)=>venueNames.map((label, vi)=>({
            slug: `${city.slug}-${[
                'grand-pavilion',
                'ivory-courtyard',
                'gardenia-estate'
            ][vi]}`,
            name: `${city.name} ${label}`,
            city: city.name,
            citySlug: city.slug,
            area: city.areas[vi],
            type: venueTypes[(ci + vi) % venueTypes.length],
            pricePerPlate: 900 + ci * 150 + vi * 400,
            capacity: {
                min: 100 + vi * 100,
                max: 500 + ci * 100 + vi * 250
            },
            rating: (4.5 + (ci + vi) % 5 * 0.1).toFixed(1),
            reviewCount: 86 + ci * 17 + vi * 12,
            veg: true,
            nonVeg: vi !== 1,
            ac: true,
            parking: vi !== 2,
            amenities: [
                'Bridal suite',
                'In-house catering',
                'Valet parking',
                'Indoor and outdoor spaces'
            ],
            about: [
                `An elegant celebration setting in ${city.name}, thoughtfully designed for joyful gatherings and unforgettable wedding days.`,
                `Our experienced event team makes every detail feel effortless, from your first visit through the final farewell.`
            ],
            images: [
                `im${[
                    1,
                    2,
                    3,
                    4,
                    12
                ][(ci + vi) % 5]}.svg`,
                `im${[
                    2,
                    3,
                    4,
                    12,
                    1
                ][(ci + vi) % 5]}.svg`,
                `im${[
                    3,
                    4,
                    12,
                    1,
                    2
                ][(ci + vi) % 5]}.svg`,
                `im${[
                    4,
                    12,
                    1,
                    2,
                    3
                ][(ci + vi) % 5]}.svg`,
                `im12.svg`
            ],
            featured: vi === 0 || ci === 1
        })));
const serviceInfo = [
    [
        'Decor',
        'Stage, mandap, entry and table styling to match your theme.',
        35000,
        5
    ],
    [
        'Photography & film',
        'Candid photos, cinematic films and pre-wedding shoots.',
        45000,
        6
    ],
    [
        'Bridal makeup',
        'Trial session, bridal look and touch-ups on the day.',
        18000,
        7
    ],
    [
        'Catering',
        'Veg and non-veg menus, live counters and tasting before you book.',
        950,
        8
    ],
    [
        'Mehendi artists',
        'Bridal and guest mehendi, traditional and modern designs.',
        12000,
        9
    ],
    [
        'DJ & music',
        'DJ, dhol, live band and sangeet choreography.',
        22000,
        10
    ]
];
const services = serviceInfo.map(([name, description, from, image], i)=>({
        name,
        slug: [
            'decor',
            'photography-film',
            'bridal-makeup',
            'catering',
            'mehendi',
            'dj-music'
        ][i],
        description,
        from,
        image: `im${image}.svg`,
        packages: [
            'Essential',
            'Signature',
            'Luxe'
        ].map((tier, j)=>({
                name: tier,
                price: from * (j + 1),
                inclusions: [
                    [
                        'Planning consultation',
                        'Core service coverage',
                        'Dedicated coordinator',
                        'Setup and teardown'
                    ][j % 4],
                    [
                        'Personalised design or schedule',
                        'Professional team',
                        'Edited delivery'
                    ][j % 3],
                    [
                        'Premium materials and upgrades',
                        'Priority support',
                        'On-day coordination'
                    ][j % 3]
                ]
            })),
        faqs: [
            [
                'Can I book this service without a venue?',
                'Absolutely. Our team can help with a standalone service or coordinate it with your venue booking.'
            ],
            [
                'Can I customise a package?',
                'Yes. Share your plans and we will tailor the inclusions and quote.'
            ],
            [
                'How early should I book?',
                'Six to twelve months is ideal for popular dates; ask us about your date.'
            ],
            [
                'Which cities do you cover?',
                'We currently help couples across eight major wedding destinations in India.'
            ],
            [
                'Is a consultation included?',
                'Yes, your first consultation and estimate are complimentary.'
            ]
        ]
    }));
const weddings = Array.from({
    length: 6
}, (_, i)=>({
        slug: [
            'a-lakeside-udaipur-celebration',
            'garden-wedding-in-goa',
            'modern-jaipur-wedding',
            'delhi-courtyard-celebration',
            'bengaluru-evening-vows',
            'mumbai-rooftop-wedding'
        ][i],
        title: [
            'A lakeside celebration in Udaipur',
            'A garden wedding in Goa',
            'A modern Jaipur wedding',
            'An intimate Delhi courtyard',
            'Evening vows in Bengaluru',
            'A rooftop wedding in Mumbai'
        ][i],
        couple: [
            'Aarav & Meera',
            'Kabir & Anya',
            'Rohan & Diya',
            'Arjun & Tara',
            'Dev & Nisha',
            'Ishaan & Rhea'
        ][i],
        city: cities[(i + 7) % 8].name,
        venue: venues[i * 3],
        images: [
            'im11.svg',
            'im5.svg',
            'im12.svg',
            'im3.svg'
        ]
    }));
const blogTitles = [
    'A practical guide to choosing your wedding venue',
    'How to plan a beautiful wedding on a budget',
    'Wedding decor ideas that feel personal',
    'Your wedding photography timeline, made simple',
    'A city-by-city destination wedding guide',
    'Questions to ask before booking a caterer'
];
const posts = blogTitles.map((title, i)=>({
        slug: [
            'choosing-your-wedding-venue',
            'wedding-budget-planning',
            'personal-wedding-decor',
            'wedding-photography-timeline',
            'destination-wedding-guide',
            'questions-for-your-caterer'
        ][i],
        title,
        excerpt: `Thoughtful advice from our planning team to make your ${[
            'venue search',
            'celebration budget',
            'wedding decor',
            'photo schedule',
            'destination plans',
            'menu tasting'
        ][i]} easier.`,
        image: `im${[
            1,
            11,
            5,
            6,
            4,
            8
        ][i]}.svg`,
        body: [
            `A wedding should feel like you. Start by listing the moments and people that matter most, then let your venue and vendor choices support those priorities.`,
            `Set your date range, guest count and comfortable spending limit before you begin shortlisting. Ask vendors for clear written inclusions, and leave a little room for the unexpected.`,
            `Visit in person when possible and picture the flow of your day. Our team can help compare options and connect the details.`
        ]
    }));
const testimonials = [
    {
        name: 'Aditi & Karan',
        quote: 'We found a beautiful venue and a team who understood exactly what we wanted. The whole process felt calm.'
    },
    {
        name: 'Simran & Varun',
        quote: 'Clear pricing and thoughtful recommendations made planning from another city so much easier.'
    },
    {
        name: 'Megha & Rishabh',
        quote: 'Every detail came together wonderfully. We could enjoy our wedding knowing the team had it handled.'
    }
];
const faqs = [
    [
        'Can I book a venue and services together?',
        'Yes. We can coordinate your venue and the services you need through one enquiry.'
    ],
    [
        'Do you help with venue visits?',
        'We can arrange a shortlist and coordinate visits around your schedule.'
    ],
    [
        'Are the prices fixed?',
        'Prices are indicative and vary with date, guest count and package inclusions.'
    ],
    [
        'Which cities do you serve?',
        'Bengaluru, Delhi, Mumbai, Goa, Noida, Gurugram, Jaipur and Udaipur.'
    ],
    [
        'How do I get started?',
        'Tell us your date, city and guest count. A planner will call with suitable options.'
    ],
    [
        'Can I customise packages?',
        'Yes, packages are a starting point and can be tailored to your plans.'
    ],
    [
        'Is the first consultation free?',
        'Yes, the first consultation and shortlist are complimentary.'
    ],
    [
        'How can venues join?',
        'Use our List your venue form and our partnerships team will be in touch.'
    ]
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_1dz0l46pn0all._.js.map