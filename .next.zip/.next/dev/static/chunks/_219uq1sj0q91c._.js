(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0p_dsfo3ujaof._.css","static/chunks/src_1dz0l46pn0all._.js","static/chunks/node_modules_next_dist_0h-wz97ptx6dd._.js","static/chunks/src_components_ServicesScroll_18u285415xp1l.js"],
    source: "entry"
});
