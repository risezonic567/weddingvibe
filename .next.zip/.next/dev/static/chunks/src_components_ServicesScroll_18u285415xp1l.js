(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/ServicesScroll.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ServicesScroll
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data/site.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Site.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function ServicesScroll() {
    _s();
    const [active, setActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const refs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ServicesScroll.useEffect": ()=>{
            const observer = new IntersectionObserver({
                "ServicesScroll.useEffect": (entries)=>{
                    const visible = entries.filter({
                        "ServicesScroll.useEffect.visible": (x)=>x.isIntersecting
                    }["ServicesScroll.useEffect.visible"]).sort({
                        "ServicesScroll.useEffect.visible": (a, b)=>Math.abs(a.boundingClientRect.top + a.boundingClientRect.height / 2 - window.innerHeight / 2) - Math.abs(b.boundingClientRect.top + b.boundingClientRect.height / 2 - window.innerHeight / 2)
                    }["ServicesScroll.useEffect.visible"]);
                    if (visible[0]) setActive(Number(visible[0].target.dataset.index));
                }
            }["ServicesScroll.useEffect"], {
                rootMargin: '-35% 0px -35% 0px',
                threshold: 0
            });
            refs.current.forEach({
                "ServicesScroll.useEffect": (node)=>node && observer.observe(node)
            }["ServicesScroll.useEffect"]);
            return ({
                "ServicesScroll.useEffect": ()=>observer.disconnect()
            })["ServicesScroll.useEffect"];
        }
    }["ServicesScroll.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "svc-home",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["services"].map((s, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                        ref: (el)=>refs.current[i] = el,
                        "data-index": i,
                        className: "svc-item",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "eyebrow",
                                children: [
                                    "0",
                                    i + 1
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ServicesScroll.js",
                                lineNumber: 6,
                                columnNumber: 753
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                children: s.name
                            }, void 0, false, {
                                fileName: "[project]/src/components/ServicesScroll.js",
                                lineNumber: 6,
                                columnNumber: 792
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: s.description
                            }, void 0, false, {
                                fileName: "[project]/src/components/ServicesScroll.js",
                                lineNumber: 6,
                                columnNumber: 809
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: `/services/${s.slug}`,
                                className: "text-link",
                                children: "Explore service →"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ServicesScroll.js",
                                lineNumber: 6,
                                columnNumber: 831
                            }, this)
                        ]
                    }, s.slug, true, {
                        fileName: "[project]/src/components/ServicesScroll.js",
                        lineNumber: 6,
                        columnNumber: 666
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/ServicesScroll.js",
                lineNumber: 6,
                columnNumber: 640
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "svc-photo-stack",
                children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["services"].map((s, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Site$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageBox"], {
                        image: s.image,
                        className: `svc-photo ${i === active ? 'visible' : ''}`,
                        alt: s.name
                    }, s.slug, false, {
                        fileName: "[project]/src/components/ServicesScroll.js",
                        lineNumber: 6,
                        columnNumber: 984
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/ServicesScroll.js",
                lineNumber: 6,
                columnNumber: 930
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ServicesScroll.js",
        lineNumber: 6,
        columnNumber: 614
    }, this);
}
_s(ServicesScroll, "3gGqgQbGXFBo2etxCXTi3djAy8U=");
_c = ServicesScroll;
var _c;
__turbopack_context__.k.register(_c, "ServicesScroll");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_ServicesScroll_18u285415xp1l.js.map