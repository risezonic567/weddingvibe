module.exports = [
"[next]/internal/font/google/playfair_display_e931a48e.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$playfair_display_e931a48e$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__ = __turbopack_context__.i("[next]/internal/font/google/playfair_display_e931a48e.module.css [app-rsc] (css module)");
;
const fontData = {
    className: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$playfair_display_e931a48e$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].className,
    style: {
        fontFamily: "'Playfair Display', 'Playfair Display Fallback'",
        fontStyle: "normal"
    }
};
if (__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$playfair_display_e931a48e$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].variable != null) {
    fontData.variable = __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$playfair_display_e931a48e$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].variable;
}
const __TURBOPACK__default__export__ = fontData;
}),
"[next]/internal/font/google/playfair_display_e931a48e.module.css [app-rsc] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "className": "playfair_display_e931a48e-module__nbjMJa__className",
  "variable": "playfair_display_e931a48e-module__nbjMJa__variable",
});
}),
"[next]/internal/font/google/poppins_44f1a43.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$poppins_44f1a43$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__ = __turbopack_context__.i("[next]/internal/font/google/poppins_44f1a43.module.css [app-rsc] (css module)");
;
const fontData = {
    className: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$poppins_44f1a43$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].className,
    style: {
        fontFamily: "'Poppins', 'Poppins Fallback'",
        fontStyle: "normal"
    }
};
if (__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$poppins_44f1a43$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].variable != null) {
    fontData.variable = __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$poppins_44f1a43$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].variable;
}
const __TURBOPACK__default__export__ = fontData;
}),
"[next]/internal/font/google/poppins_44f1a43.module.css [app-rsc] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "className": "poppins_44f1a43-module__mPCbcW__className",
  "variable": "poppins_44f1a43-module__mPCbcW__variable",
});
}),
"[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-rsc] (ecmascript)").vendored['react-rsc'].ReactJsxDevRuntime;
}),
"[project]/src/app/layout.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RootLayout,
    "metadata",
    ()=>metadata
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$playfair_display_e931a48e$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[next]/internal/font/google/playfair_display_e931a48e.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$poppins_44f1a43$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[next]/internal/font/google/poppins_44f1a43.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Site$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Site.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data/site.js [app-rsc] (ecmascript)");
;
;
;
;
;
;
const metadata = {
    metadataBase: new URL('https://weddingsvibe.com'),
    title: {
        default: 'Weddings Vibe | Find your wedding venue and team',
        template: '%s | Weddings Vibe'
    },
    description: 'Discover beautiful wedding venues and trusted wedding services across India. One enquiry brings your celebration together.',
    openGraph: {
        siteName: 'Weddings Vibe',
        type: 'website',
        locale: 'en_IN'
    }
};
function RootLayout({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("html", {
        lang: "en",
        className: `${__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$playfair_display_e931a48e$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].variable} ${__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$poppins_44f1a43$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].variable}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("body", {
            id: "top",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("script", {
                    type: "application/ld+json",
                    dangerouslySetInnerHTML: {
                        __html: JSON.stringify({
                            '@context': 'https://schema.org',
                            '@type': 'Organization',
                            name: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["site"].name,
                            url: 'https://weddingsvibe.com',
                            email: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["site"].email,
                            telephone: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["site"].phone,
                            sameAs: Object.values(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$site$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["site"].socials)
                        })
                    }
                }, void 0, false, {
                    fileName: "[project]/src/app/layout.js",
                    lineNumber: 9,
                    columnNumber: 145
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Site$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Shell"], {
                    children: children
                }, void 0, false, {
                    fileName: "[project]/src/app/layout.js",
                    lineNumber: 9,
                    columnNumber: 408
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/layout.js",
            lineNumber: 9,
            columnNumber: 130
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/layout.js",
        lineNumber: 9,
        columnNumber: 59
    }, this);
}
}),
"[project]/src/app/layout.js [app-rsc] (ecmascript, Next.js Server Component)", (function(__turbopack_context__){

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.js [app-rsc] (ecmascript)"));
}),
"[project]/src/components/Site.js [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BudgetPlanner",
    ()=>BudgetPlanner,
    "EnquiryForm",
    ()=>EnquiryForm,
    "Footer",
    ()=>Footer,
    "Header",
    ()=>Header,
    "ImageBox",
    ()=>ImageBox,
    "Shell",
    ()=>Shell,
    "VenueCard",
    ()=>VenueCard
]);
// This file is generated by next-core EcmascriptClientReferenceModule.
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const BudgetPlanner = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call BudgetPlanner() from the server but BudgetPlanner is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/Site.js", "BudgetPlanner");
const EnquiryForm = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call EnquiryForm() from the server but EnquiryForm is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/Site.js", "EnquiryForm");
const Footer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Footer() from the server but Footer is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/Site.js", "Footer");
const Header = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Header() from the server but Header is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/Site.js", "Header");
const ImageBox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ImageBox() from the server but ImageBox is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/Site.js", "ImageBox");
const Shell = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Shell() from the server but Shell is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/Site.js", "Shell");
const VenueCard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call VenueCard() from the server but VenueCard is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/Site.js", "VenueCard");
}),
"[project]/src/components/Site.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Site$2e$js__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/src/components/Site.js [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Site$2e$js__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/src/data/site.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cities",
    ()=>cities,
    "faqs",
    ()=>faqs,
    "posts",
    ()=>posts,
    "services",
    ()=>services,
    "site",
    ()=>site,
    "testimonials",
    ()=>testimonials,
    "venues",
    ()=>venues,
    "weddings",
    ()=>weddings
]);
const site = {
    name: 'Weddings Vibe',
    tagline: 'Wedding venues and services, one enquiry away.',
    address: '12 Sample Road, New Delhi - 110001',
    phone: '+91 00000 00000',
    phoneLink: '+910000000000',
    whatsapp: '910000000000',
    email: 'hello@weddingsvibe.com',
    instagram: '@weddingsvibe',
    socials: {
        instagram: 'https://instagram.com/weddingsvibe',
        linkedin: 'https://linkedin.com',
        youtube: 'https://youtube.com',
        pinterest: 'https://pinterest.com'
    },
    hours: 'Monday to Saturday, 10 am – 7 pm',
    nav: [
        {
            label: 'Venues',
            href: '/venues'
        },
        {
            label: 'Services',
            href: '/services'
        },
        {
            label: 'Real Weddings',
            href: '/real-weddings'
        },
        {
            label: 'Blog',
            href: '/blog'
        },
        {
            label: 'Contact',
            href: '/contact'
        }
    ]
};
const cityInfo = [
    [
        'Bengaluru',
        'Indiranagar',
        'Whitefield',
        'J.P. Nagar'
    ],
    [
        'Delhi',
        'Dwarka',
        'Saket',
        'Chattarpur'
    ],
    [
        'Mumbai',
        'Bandra',
        'Powai',
        'Andheri'
    ],
    [
        'Goa',
        'Candolim',
        'Assagao',
        'Vagator'
    ],
    [
        'Noida',
        'Sector 18',
        'Sector 62',
        'Greater Noida'
    ],
    [
        'Gurugram',
        'Golf Course Road',
        'Sohna Road',
        'Manesar'
    ],
    [
        'Jaipur',
        'Amer Road',
        'Tonk Road',
        'Civil Lines'
    ],
    [
        'Udaipur',
        'Lake Pichola',
        'Fateh Sagar',
        'Hiran Magri'
    ]
];
const cities = cityInfo.map(([name, ...areas], i)=>({
        name,
        slug: name.toLowerCase().replaceAll(' ', '-'),
        areas,
        landmark: [
            'Vidhana Soudha',
            'India Gate',
            'Gateway of India',
            'Fort Aguada',
            'Okhla Bird Sanctuary',
            'Kingdom of Dreams',
            'Hawa Mahal',
            'City Palace'
        ][i]
    }));
const venueNames = [
    'The Grand Pavilion',
    'Ivory Courtyard',
    'Gardenia Estate'
];
const venueTypes = [
    'banquet',
    'palace',
    'farmhouse',
    'resort',
    'beach',
    'destination'
];
const venues = cities.flatMap((city, ci)=>venueNames.map((label, vi)=>({
            slug: `${city.slug}-${[
                'grand-pavilion',
                'ivory-courtyard',
                'gardenia-estate'
            ][vi]}`,
            name: `${city.name} ${label}`,
            city: city.name,
            citySlug: city.slug,
            area: city.areas[vi],
            type: venueTypes[(ci + vi) % venueTypes.length],
            pricePerPlate: 900 + ci * 150 + vi * 400,
            capacity: {
                min: 100 + vi * 100,
                max: 500 + ci * 100 + vi * 250
            },
            rating: (4.5 + (ci + vi) % 5 * 0.1).toFixed(1),
            reviewCount: 86 + ci * 17 + vi * 12,
            veg: true,
            nonVeg: vi !== 1,
            ac: true,
            parking: vi !== 2,
            amenities: [
                'Bridal suite',
                'In-house catering',
                'Valet parking',
                'Indoor and outdoor spaces'
            ],
            about: [
                `An elegant celebration setting in ${city.name}, thoughtfully designed for joyful gatherings and unforgettable wedding days.`,
                `Our experienced event team makes every detail feel effortless, from your first visit through the final farewell.`
            ],
            images: [
                `im${[
                    1,
                    2,
                    3,
                    4,
                    12
                ][(ci + vi) % 5]}.svg`,
                `im${[
                    2,
                    3,
                    4,
                    12,
                    1
                ][(ci + vi) % 5]}.svg`,
                `im${[
                    3,
                    4,
                    12,
                    1,
                    2
                ][(ci + vi) % 5]}.svg`,
                `im${[
                    4,
                    12,
                    1,
                    2,
                    3
                ][(ci + vi) % 5]}.svg`,
                `im12.svg`
            ],
            featured: vi === 0 || ci === 1
        })));
const serviceInfo = [
    [
        'Decor',
        'Stage, mandap, entry and table styling to match your theme.',
        35000,
        5
    ],
    [
        'Photography & film',
        'Candid photos, cinematic films and pre-wedding shoots.',
        45000,
        6
    ],
    [
        'Bridal makeup',
        'Trial session, bridal look and touch-ups on the day.',
        18000,
        7
    ],
    [
        'Catering',
        'Veg and non-veg menus, live counters and tasting before you book.',
        950,
        8
    ],
    [
        'Mehendi artists',
        'Bridal and guest mehendi, traditional and modern designs.',
        12000,
        9
    ],
    [
        'DJ & music',
        'DJ, dhol, live band and sangeet choreography.',
        22000,
        10
    ]
];
const services = serviceInfo.map(([name, description, from, image], i)=>({
        name,
        slug: [
            'decor',
            'photography-film',
            'bridal-makeup',
            'catering',
            'mehendi',
            'dj-music'
        ][i],
        description,
        from,
        image: `im${image}.svg`,
        packages: [
            'Essential',
            'Signature',
            'Luxe'
        ].map((tier, j)=>({
                name: tier,
                price: from * (j + 1),
                inclusions: [
                    [
                        'Planning consultation',
                        'Core service coverage',
                        'Dedicated coordinator',
                        'Setup and teardown'
                    ][j % 4],
                    [
                        'Personalised design or schedule',
                        'Professional team',
                        'Edited delivery'
                    ][j % 3],
                    [
                        'Premium materials and upgrades',
                        'Priority support',
                        'On-day coordination'
                    ][j % 3]
                ]
            })),
        faqs: [
            [
                'Can I book this service without a venue?',
                'Absolutely. Our team can help with a standalone service or coordinate it with your venue booking.'
            ],
            [
                'Can I customise a package?',
                'Yes. Share your plans and we will tailor the inclusions and quote.'
            ],
            [
                'How early should I book?',
                'Six to twelve months is ideal for popular dates; ask us about your date.'
            ],
            [
                'Which cities do you cover?',
                'We currently help couples across eight major wedding destinations in India.'
            ],
            [
                'Is a consultation included?',
                'Yes, your first consultation and estimate are complimentary.'
            ]
        ]
    }));
const weddings = Array.from({
    length: 6
}, (_, i)=>({
        slug: [
            'a-lakeside-udaipur-celebration',
            'garden-wedding-in-goa',
            'modern-jaipur-wedding',
            'delhi-courtyard-celebration',
            'bengaluru-evening-vows',
            'mumbai-rooftop-wedding'
        ][i],
        title: [
            'A lakeside celebration in Udaipur',
            'A garden wedding in Goa',
            'A modern Jaipur wedding',
            'An intimate Delhi courtyard',
            'Evening vows in Bengaluru',
            'A rooftop wedding in Mumbai'
        ][i],
        couple: [
            'Aarav & Meera',
            'Kabir & Anya',
            'Rohan & Diya',
            'Arjun & Tara',
            'Dev & Nisha',
            'Ishaan & Rhea'
        ][i],
        city: cities[(i + 7) % 8].name,
        venue: venues[i * 3],
        images: [
            'im11.svg',
            'im5.svg',
            'im12.svg',
            'im3.svg'
        ]
    }));
const blogTitles = [
    'A practical guide to choosing your wedding venue',
    'How to plan a beautiful wedding on a budget',
    'Wedding decor ideas that feel personal',
    'Your wedding photography timeline, made simple',
    'A city-by-city destination wedding guide',
    'Questions to ask before booking a caterer'
];
const posts = blogTitles.map((title, i)=>({
        slug: [
            'choosing-your-wedding-venue',
            'wedding-budget-planning',
            'personal-wedding-decor',
            'wedding-photography-timeline',
            'destination-wedding-guide',
            'questions-for-your-caterer'
        ][i],
        title,
        excerpt: `Thoughtful advice from our planning team to make your ${[
            'venue search',
            'celebration budget',
            'wedding decor',
            'photo schedule',
            'destination plans',
            'menu tasting'
        ][i]} easier.`,
        image: `im${[
            1,
            11,
            5,
            6,
            4,
            8
        ][i]}.svg`,
        body: [
            `A wedding should feel like you. Start by listing the moments and people that matter most, then let your venue and vendor choices support those priorities.`,
            `Set your date range, guest count and comfortable spending limit before you begin shortlisting. Ask vendors for clear written inclusions, and leave a little room for the unexpected.`,
            `Visit in person when possible and picture the flow of your day. Our team can help compare options and connect the details.`
        ]
    }));
const testimonials = [
    {
        name: 'Aditi & Karan',
        quote: 'We found a beautiful venue and a team who understood exactly what we wanted. The whole process felt calm.'
    },
    {
        name: 'Simran & Varun',
        quote: 'Clear pricing and thoughtful recommendations made planning from another city so much easier.'
    },
    {
        name: 'Megha & Rishabh',
        quote: 'Every detail came together wonderfully. We could enjoy our wedding knowing the team had it handled.'
    }
];
const faqs = [
    [
        'Can I book a venue and services together?',
        'Yes. We can coordinate your venue and the services you need through one enquiry.'
    ],
    [
        'Do you help with venue visits?',
        'We can arrange a shortlist and coordinate visits around your schedule.'
    ],
    [
        'Are the prices fixed?',
        'Prices are indicative and vary with date, guest count and package inclusions.'
    ],
    [
        'Which cities do you serve?',
        'Bengaluru, Delhi, Mumbai, Goa, Noida, Gurugram, Jaipur and Udaipur.'
    ],
    [
        'How do I get started?',
        'Tell us your date, city and guest count. A planner will call with suitable options.'
    ],
    [
        'Can I customise packages?',
        'Yes, packages are a starting point and can be tailored to your plans.'
    ],
    [
        'Is the first consultation free?',
        'Yes, the first consultation and shortlist are complimentary.'
    ],
    [
        'How can venues join?',
        'Use our List your venue form and our partnerships team will be in touch.'
    ]
];
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0rpkic_seytqf._.js.map