module.exports=[29928,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_real-weddings_%5Bslug%5D_page_actions_1ysh3th_ppoxx.js.map