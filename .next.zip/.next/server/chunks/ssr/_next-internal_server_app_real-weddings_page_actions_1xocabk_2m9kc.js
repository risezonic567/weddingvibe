module.exports=[47962,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_real-weddings_page_actions_1xocabk_2m9kc.js.map