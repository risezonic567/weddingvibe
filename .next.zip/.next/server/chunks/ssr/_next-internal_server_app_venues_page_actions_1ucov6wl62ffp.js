module.exports=[87973,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_venues_page_actions_1ucov6wl62ffp.js.map