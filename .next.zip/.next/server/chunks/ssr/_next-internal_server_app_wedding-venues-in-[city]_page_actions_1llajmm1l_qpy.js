module.exports=[40798,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_wedding-venues-in-%5Bcity%5D_page_actions_1llajmm1l_qpy.js.map