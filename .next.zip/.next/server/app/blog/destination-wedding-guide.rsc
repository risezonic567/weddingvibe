#1:"$Sreact.fragment"
2:"/_next/static/chunks/3l5l8-x2c57rc.js"
3:"/_next/static/chunks/0mwf796fak0sn.js"
4:I[37895,["$2","$3"],"Shell"]
5:I[39756,["$2","$3"],"default"]
6:I[37457,["$2","$3"],"default"]
7:I[22016,["$2","$3"],""]
e:I[97367,["$2","$3"],"OutletBoundary"]
f:"$Sreact.suspense"
12:"ViewportBoundary"
13:I[97367,["$2","$3"],"$12"]
15:"MetadataBoundary"
16:I[97367,["$2","$3"],"$15"]
19:I[68027,["$2","$3"],"default",1]
:HL["/_next/static/chunks/1uec42u55d2ie.css","style"]
:HL["/_next/static/media/22a701959b157a82-s.p.2o7m9ogm38dql.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/6bafae418e8a1b08-s.p.3o_v2fun1jzxk.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/76e9fd951b869c7b-s.p.3bh2vc0w-r-ll.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/9d036f80216c14ee-s.p.3u4lli0-axodc.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/dd9dfc3601372168-s.p.43zbiuwnnoiok.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
8:X
a:X
11:X
c:[["children",{"s":"__PAGE__","h":514,"d":{"r":["$","$1","c",{"children":["$Ld",null,["$","$Le",null,{"children":["$","$f",null,{"name":"Next.MetadataOutlet","children":"$@10"}]}]]}],"p":true,"v":"$11"}}]]
b:[["children",{"s":{"n":"slug","t":"d","k":"destination-wedding-guide","s":[]},"h":514,"d":{"r":["$","$1","c",{"children":[null,["$","$L5",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L6",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":true,"v":"$a"},"c":"$Qc"}]]
9:[["children",{"s":"blog","h":514,"d":{"r":["$","$1","c",{"children":[null,["$","$L5",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L6",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":true,"v":"$a"},"c":"$Qb"}]]
18:X
1a:X
1b:X
0:{"P":null,"c":["","blog","destination-wedding-guide"],"q":"","i":false,"t":{"t":{"s":"","h":530,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1uec42u55d2ie.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/3l5l8-x2c57rc.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/0mwf796fak0sn.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"nbjMJa_variable mPCbcW_variable","children":["$","body",null,{"id":"top","children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Organization\",\"name\":\"Weddings Vibe\",\"url\":\"https://weddingsvibe.com\",\"email\":\"hello@weddingsvibe.com\",\"telephone\":\"+91 00000 00000\",\"sameAs\":[\"https://instagram.com/weddingsvibe\",\"https://linkedin.com\",\"https://youtube.com\",\"https://pinterest.com\"]}"}}],["$","$L4",null,{"children":["$","$L5",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L6",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","section",null,{"className":"sec","children":["$","div",null,{"className":"wrap center","children":[["$","p",null,{"className":"eyebrow","children":"404 · PAGE NOT FOUND"}],["$","h1",null,{"className":"h2","children":"This page wandered off."}],["$","p",null,{"className":"sub","children":"Let’s find your way back to a beautiful beginning."}],["$","$L7",null,{"className":"btn","href":"/","children":"Back to weddingsvibe"}]]}]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]]}]}]]}],"p":true,"v":"$8"},"c":"$Q9"},"h":{"r":["$","$1","h",{"children":[null,["$","$L13",null,{"children":"$L14"}],["$","$L16",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$f",null,{"name":"Next.Metadata","children":"$L17"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":true,"v":"$18"}},"m":"$undefined","G":["$19",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1uec42u55d2ie.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$1a","s":"$1b","a":"$@1c","l":"$undefined","p":"$undefined","d":"$undefined","b":"mCoMypNjACZUq3qcz_-Wu","u":"$@1d"}
a:C
1b:300
14:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
11:T4,slug18:T4,slug1e:I[37895,["$2","$3"],"ImageBox"]
1f:I[27201,["$2","$3"],"IconMark"]
d:["$","article",null,{"className":"sec","children":["$","div",null,{"className":"wrap narrow","children":[["$","p",null,{"className":"eyebrow","children":"THE WEDDING JOURNAL"}],["$","h1",null,{"className":"h2","children":"A city-by-city destination wedding guide"}],["$","p",null,{"className":"sub","children":"Thoughtful advice from our planning team to make your destination plans easier."}],["$","$L1e",null,{"image":"im4.svg","className":"story-cover","alt":"A city-by-city destination wedding guide"}],[["$","p","0",{"children":"A wedding should feel like you. Start by listing the moments and people that matter most, then let your venue and vendor choices support those priorities."}],["$","p","1",{"children":"Set your date range, guest count and comfortable spending limit before you begin shortlisting. Ask vendors for clear written inclusions, and leave a little room for the unexpected."}],["$","p","2",{"children":"Visit in person when possible and picture the flow of your day. Our team can help compare options and connect the details."}],["$","p","3",{"children":"A wedding should feel like you. Start by listing the moments and people that matter most, then let your venue and vendor choices support those priorities."}],["$","p","4",{"children":"Set your date range, guest count and comfortable spending limit before you begin shortlisting. Ask vendors for clear written inclusions, and leave a little room for the unexpected."}],["$","p","5",{"children":"Visit in person when possible and picture the flow of your day. Our team can help compare options and connect the details."}],["$","p","6",{"children":"A wedding should feel like you. Start by listing the moments and people that matter most, then let your venue and vendor choices support those priorities."}],["$","p","7",{"children":"Set your date range, guest count and comfortable spending limit before you begin shortlisting. Ask vendors for clear written inclusions, and leave a little room for the unexpected."}],["$","p","8",{"children":"Visit in person when possible and picture the flow of your day. Our team can help compare options and connect the details."}]],["$","h2",null,{"children":"Make a plan that feels right"}],["$","p",null,{"children":"Every celebration is different. Start with what matters most, then build a team you trust around it."}],["$","a",null,{"className":"btn","href":"/contact","children":"Talk with a planner"}]]}]}]
10:null
17:[["$","title","0",{"children":"A city-by-city destination wedding guide | Weddings Vibe"}],["$","meta","1",{"name":"description","content":"Thoughtful advice from our planning team to make your destination plans easier."}],["$","meta","2",{"property":"og:title","content":"A city-by-city destination wedding guide | Weddings Vibe"}],["$","meta","3",{"property":"og:description","content":"Thoughtful advice from our planning team to make your destination plans easier."}],["$","meta","4",{"property":"og:site_name","content":"Weddings Vibe"}],["$","meta","5",{"property":"og:locale","content":"en_IN"}],["$","meta","6",{"property":"og:type","content":"website"}],["$","meta","7",{"name":"twitter:card","content":"summary"}],["$","meta","8",{"name":"twitter:title","content":"A city-by-city destination wedding guide | Weddings Vibe"}],["$","meta","9",{"name":"twitter:description","content":"Thoughtful advice from our planning team to make your destination plans easier."}],["$","link","10",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","link","11",{"rel":"icon","href":"/icon.png?icon.14cylqv-rudw7.png","sizes":"512x512","type":"image/png"}],["$","$L1f","12",{}]]
1b:C
18:C
1a:C
11:C
8:C
1d:false
1c:4755
