1:"$Sreact.fragment"
2:"/_next/static/chunks/3l5l8-x2c57rc.js"
3:"/_next/static/chunks/0mwf796fak0sn.js"
4:I[37895,["$2","$3"],"Shell"]
5:I[39756,["$2","$3"],"default"]
6:I[37457,["$2","$3"],"default"]
7:I[22016,["$2","$3"],""]
e:I[97367,["$2","$3"],"OutletBoundary"]
f:"$Sreact.suspense"
12:"ViewportBoundary"
13:I[97367,["$2","$3"],"$12"]
15:"MetadataBoundary"
16:I[97367,["$2","$3"],"$15"]
19:I[68027,["$2","$3"],"default",1]
:HL["/_next/static/chunks/1uec42u55d2ie.css","style"]
:HL["/_next/static/media/22a701959b157a82-s.p.2o7m9ogm38dql.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/6bafae418e8a1b08-s.p.3o_v2fun1jzxk.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/76e9fd951b869c7b-s.p.3bh2vc0w-r-ll.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/9d036f80216c14ee-s.p.3u4lli0-axodc.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/dd9dfc3601372168-s.p.43zbiuwnnoiok.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
8:X
a:X
11:X
c:[["children",{"s":"__PAGE__","h":514,"d":{"r":["$","$1","c",{"children":["$Ld",null,["$","$Le",null,{"children":["$","$f",null,{"name":"Next.MetadataOutlet","children":"$@10"}]}]]}],"p":true,"v":"$11"}}]]
b:[["children",{"s":{"n":"slug","t":"d","k":"garden-wedding-in-goa","s":[]},"h":514,"d":{"r":["$","$1","c",{"children":[null,["$","$L5",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L6",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":true,"v":"$a"},"c":"$Qc"}]]
9:[["children",{"s":"real-weddings","h":514,"d":{"r":["$","$1","c",{"children":[null,["$","$L5",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L6",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":true,"v":"$a"},"c":"$Qb"}]]
18:X
1a:X
1b:X
0:{"P":null,"c":["","real-weddings","garden-wedding-in-goa"],"q":"","i":false,"t":{"t":{"s":"","h":530,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1uec42u55d2ie.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/3l5l8-x2c57rc.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/0mwf796fak0sn.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"nbjMJa_variable mPCbcW_variable","children":["$","body",null,{"id":"top","children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Organization\",\"name\":\"Weddings Vibe\",\"url\":\"https://weddingsvibe.com\",\"email\":\"hello@weddingsvibe.com\",\"telephone\":\"+91 00000 00000\",\"sameAs\":[\"https://instagram.com/weddingsvibe\",\"https://linkedin.com\",\"https://youtube.com\",\"https://pinterest.com\"]}"}}],["$","$L4",null,{"children":["$","$L5",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L6",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","section",null,{"className":"sec","children":["$","div",null,{"className":"wrap center","children":[["$","p",null,{"className":"eyebrow","children":"404 · PAGE NOT FOUND"}],["$","h1",null,{"className":"h2","children":"This page wandered off."}],["$","p",null,{"className":"sub","children":"Let’s find your way back to a beautiful beginning."}],["$","$L7",null,{"className":"btn","href":"/","children":"Back to weddingsvibe"}]]}]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]]}]}]]}],"p":true,"v":"$8"},"c":"$Q9"},"h":{"r":["$","$1","h",{"children":[null,["$","$L13",null,{"children":"$L14"}],["$","$L16",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$f",null,{"name":"Next.Metadata","children":"$L17"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":true,"v":"$18"}},"m":"$undefined","G":["$19",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1uec42u55d2ie.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$1a","s":"$1b","a":"$@1c","l":"$undefined","p":"$undefined","d":"$undefined","b":"mCoMypNjACZUq3qcz_-Wu","u":"$@1d"}
a:C
1b:300
14:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
11:T4,slug18:T4,slug1e:I[37895,["$2","$3"],"ImageBox"]
1f:I[37895,["$2","$3"],"EnquiryForm"]
20:I[27201,["$2","$3"],"IconMark"]
d:["$","article",null,{"className":"sec","children":["$","div",null,{"className":"wrap","children":[["$","p",null,{"className":"eyebrow","children":["REAL WEDDINGS · ","BENGALURU"]}],["$","h1",null,{"className":"h2","children":"A garden wedding in Goa"}],["$","p",null,{"className":"sub","children":"Kabir & Anya"}],["$","$L1e",null,{"image":"im11.svg","className":"story-cover","alt":"Kabir & Anya wedding in Bengaluru"}],["$","div",null,{"className":"narrow story-text","children":[["$","h2",null,{"children":"A day that felt like theirs"}],["$","p",null,{"children":["When ","Kabir & Anya"," started planning in ","Bengaluru",", they knew they wanted a celebration full of warmth, personal touches and time with the people they love. Together we found a setting that felt just right and brought a thoughtful team around them."]}],["$","p",null,{"children":"From the first welcome to the last dance, every detail reflected their story. Their favourite part? Being present for it all, knowing someone had the small things taken care of."}],["$","div",null,{"className":"card story-details","children":[["$","h3",null,{"children":"The celebration"}],["$","p",null,{"children":["City: ","Bengaluru"]}],["$","p",null,{"children":["Venue: ",["$","$L7",null,{"href":"/venues/delhi/delhi-grand-pavilion","children":"Delhi The Grand Pavilion"}]]}],["$","p",null,{"children":["Services: ",[["$","$L7","decor",{"href":"/services/decor","children":["Decor"," · "]}],["$","$L7","photography-film",{"href":"/services/photography-film","children":["Photography & film"," · "]}],["$","$L7","bridal-makeup",{"href":"/services/bridal-makeup","children":["Bridal makeup"," · "]}]]]}]]}],["$","blockquote",null,{"children":["“We could be there for every moment. The planning felt simple and the day felt like us.”",["$","cite",null,{"children":["— ","Kabir & Anya"]}]]}],["$","$L1f",null,{"type":"contact","subject":"Plan a celebration like this"}]]}]]}]}]
10:null
17:[["$","title","0",{"children":"A garden wedding in Goa | Weddings Vibe"}],["$","meta","1",{"name":"description","content":"Kabir & Anya celebrated their wedding in Bengaluru. Read their story."}],["$","meta","2",{"property":"og:title","content":"A garden wedding in Goa | Weddings Vibe"}],["$","meta","3",{"property":"og:description","content":"Kabir & Anya celebrated their wedding in Bengaluru. Read their story."}],["$","meta","4",{"property":"og:site_name","content":"Weddings Vibe"}],["$","meta","5",{"property":"og:locale","content":"en_IN"}],["$","meta","6",{"property":"og:type","content":"website"}],["$","meta","7",{"name":"twitter:card","content":"summary"}],["$","meta","8",{"name":"twitter:title","content":"A garden wedding in Goa | Weddings Vibe"}],["$","meta","9",{"name":"twitter:description","content":"Kabir & Anya celebrated their wedding in Bengaluru. Read their story."}],["$","link","10",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","link","11",{"rel":"icon","href":"/icon.png?icon.14cylqv-rudw7.png","sizes":"512x512","type":"image/png"}],["$","$L20","12",{}]]
1b:C
18:C
1a:C
11:C
8:C
1d:false
1c:4765
