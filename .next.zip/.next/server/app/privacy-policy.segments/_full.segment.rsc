1:"$Sreact.fragment"
2:"/_next/static/chunks/3l5l8-x2c57rc.js"
3:"/_next/static/chunks/0mwf796fak0sn.js"
4:I[37895,["$2","$3"],"Shell"]
5:I[39756,["$2","$3"],"default"]
6:I[37457,["$2","$3"],"default"]
7:I[22016,["$2","$3"],""]
c:I[97367,["$2","$3"],"OutletBoundary"]
d:"$Sreact.suspense"
10:"ViewportBoundary"
11:I[97367,["$2","$3"],"$10"]
13:"MetadataBoundary"
14:I[97367,["$2","$3"],"$13"]
17:I[68027,["$2","$3"],"default",1]
:HL["/_next/static/chunks/1uec42u55d2ie.css","style"]
:HL["/_next/static/media/22a701959b157a82-s.p.2o7m9ogm38dql.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/6bafae418e8a1b08-s.p.3o_v2fun1jzxk.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/76e9fd951b869c7b-s.p.3bh2vc0w-r-ll.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/9d036f80216c14ee-s.p.3u4lli0-axodc.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/dd9dfc3601372168-s.p.43zbiuwnnoiok.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
8:X
a:X
f:X
b:[["children",{"s":"__PAGE__","h":514,"d":{"r":["$","$1","c",{"children":[["$","section",null,{"className":"sec","children":["$","article",null,{"className":"wrap narrow","children":[["$","h1",null,{"className":"h2","children":"Privacy policy"}],["$","p",null,{"className":"sub","children":"Last updated November 2026"}],["$","h2",null,{"children":"Information you share"}],["$","p",null,{"children":"When you make an enquiry, we collect the contact details and wedding preferences you choose to share so our planning team can respond and help with suitable options."}],["$","h2",null,{"children":"How we use information"}],["$","p",null,{"children":"We use your information to reply to enquiries, coordinate venue and service recommendations, and improve our planning experience. We do not sell your personal information."}],["$","h2",null,{"children":"Your choices"}],["$","p",null,{"children":"To ask about, update or remove your enquiry information, contact hello@weddingsvibe.com."}]]}]}],null,["$","$Lc",null,{"children":["$","$d",null,{"name":"Next.MetadataOutlet","children":"$@e"}]}]]}],"p":true,"v":"$f"}}]]
9:[["children",{"s":"privacy-policy","h":514,"d":{"r":["$","$1","c",{"children":[null,["$","$L5",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L6",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":true,"v":"$a"},"c":"$Qb"}]]
16:X
18:X
19:X
0:{"P":null,"c":["","privacy-policy"],"q":"","i":false,"t":{"t":{"s":"","h":530,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1uec42u55d2ie.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/3l5l8-x2c57rc.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/0mwf796fak0sn.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"nbjMJa_variable mPCbcW_variable","children":["$","body",null,{"id":"top","children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Organization\",\"name\":\"Weddings Vibe\",\"url\":\"https://weddingsvibe.com\",\"email\":\"hello@weddingsvibe.com\",\"telephone\":\"+91 00000 00000\",\"sameAs\":[\"https://instagram.com/weddingsvibe\",\"https://linkedin.com\",\"https://youtube.com\",\"https://pinterest.com\"]}"}}],["$","$L4",null,{"children":["$","$L5",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L6",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","section",null,{"className":"sec","children":["$","div",null,{"className":"wrap center","children":[["$","p",null,{"className":"eyebrow","children":"404 · PAGE NOT FOUND"}],["$","h1",null,{"className":"h2","children":"This page wandered off."}],["$","p",null,{"className":"sub","children":"Let’s find your way back to a beautiful beginning."}],["$","$L7",null,{"className":"btn","href":"/","children":"Back to weddingsvibe"}]]}]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]]}]}]]}],"p":true,"v":"$8"},"c":"$Q9"},"h":{"r":["$","$1","h",{"children":[null,["$","$L11",null,{"children":"$L12"}],["$","$L14",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$d",null,{"name":"Next.Metadata","children":"$L15"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":true,"v":"$16"}},"m":"$undefined","G":["$17",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1uec42u55d2ie.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$18","s":"$19","a":"$@1a","l":"$undefined","p":"$undefined","d":"$undefined","b":"mCoMypNjACZUq3qcz_-Wu","u":"$@1b"}
a:C
19:300
12:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
1c:I[27201,["$2","$3"],"IconMark"]
e:null
15:[["$","title","0",{"children":"Privacy policy | Weddings Vibe"}],["$","meta","1",{"name":"description","content":"How weddingsvibe handles your information."}],["$","meta","2",{"property":"og:title","content":"Privacy policy | Weddings Vibe"}],["$","meta","3",{"property":"og:description","content":"How weddingsvibe handles your information."}],["$","meta","4",{"property":"og:site_name","content":"Weddings Vibe"}],["$","meta","5",{"property":"og:locale","content":"en_IN"}],["$","meta","6",{"property":"og:type","content":"website"}],["$","meta","7",{"name":"twitter:card","content":"summary"}],["$","meta","8",{"name":"twitter:title","content":"Privacy policy | Weddings Vibe"}],["$","meta","9",{"name":"twitter:description","content":"How weddingsvibe handles your information."}],["$","link","10",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","link","11",{"rel":"icon","href":"/icon.png?icon.14cylqv-rudw7.png","sizes":"512x512","type":"image/png"}],["$","$L1c","12",{}]]
19:C
16:C
18:C
f:C
8:C
1b:false
1a:null
