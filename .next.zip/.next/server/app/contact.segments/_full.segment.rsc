1:"$Sreact.fragment"
2:"/_next/static/chunks/3l5l8-x2c57rc.js"
3:"/_next/static/chunks/0mwf796fak0sn.js"
4:I[37895,["$2","$3"],"Shell"]
5:I[39756,["$2","$3"],"default"]
6:I[37457,["$2","$3"],"default"]
7:I[22016,["$2","$3"],""]
c:I[37895,["$2","$3"],"EnquiryForm"]
d:I[97367,["$2","$3"],"OutletBoundary"]
e:"$Sreact.suspense"
11:"ViewportBoundary"
12:I[97367,["$2","$3"],"$11"]
14:"MetadataBoundary"
15:I[97367,["$2","$3"],"$14"]
18:I[68027,["$2","$3"],"default",1]
:HL["/_next/static/chunks/1uec42u55d2ie.css","style"]
:HL["/_next/static/media/22a701959b157a82-s.p.2o7m9ogm38dql.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/6bafae418e8a1b08-s.p.3o_v2fun1jzxk.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/76e9fd951b869c7b-s.p.3bh2vc0w-r-ll.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/9d036f80216c14ee-s.p.3u4lli0-axodc.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/dd9dfc3601372168-s.p.43zbiuwnnoiok.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
8:X
a:X
10:X
b:[["children",{"s":"__PAGE__","h":514,"d":{"r":["$","$1","c",{"children":[["$","section",null,{"className":"sec","children":["$","div",null,{"className":"wrap detail-split","children":[["$","div",null,{"children":[["$","p",null,{"className":"eyebrow","children":"WE’RE HERE TO HELP"}],["$","h1",null,{"className":"h2","children":"Let’s talk about your day."}],["$","p",null,{"className":"sub","children":"Tell us what you’re planning. Our wedding team will be happy to help with a thoughtful shortlist."}],["$","p",null,{"children":[["$","a",null,{"href":"tel:+910000000000","children":"+91 00000 00000"}],["$","br",null,{}],["$","a",null,{"href":"mailto:hello@weddingsvibe.com","children":"hello@weddingsvibe.com"}]]}],["$","div",null,{"className":"mapblock","children":["12 Sample Road, New Delhi - 110001",["$","a",null,{"href":"https://maps.google.com/?q=12+Sample+Road+New+Delhi","children":"Get directions ↗"}]]}],["$","a",null,{"className":"btn","href":"https://wa.me/910000000000","children":"Chat on WhatsApp"}]]}],["$","$Lc",null,{"type":"contact","subject":"Send us an enquiry"}]]}]}],null,["$","$Ld",null,{"children":["$","$e",null,{"name":"Next.MetadataOutlet","children":"$@f"}]}]]}],"p":true,"v":"$10"}}]]
9:[["children",{"s":"contact","h":514,"d":{"r":["$","$1","c",{"children":[null,["$","$L5",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L6",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":true,"v":"$a"},"c":"$Qb"}]]
17:X
19:X
1a:X
0:{"P":null,"c":["","contact"],"q":"","i":false,"t":{"t":{"s":"","h":530,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1uec42u55d2ie.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/3l5l8-x2c57rc.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/0mwf796fak0sn.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"nbjMJa_variable mPCbcW_variable","children":["$","body",null,{"id":"top","children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Organization\",\"name\":\"Weddings Vibe\",\"url\":\"https://weddingsvibe.com\",\"email\":\"hello@weddingsvibe.com\",\"telephone\":\"+91 00000 00000\",\"sameAs\":[\"https://instagram.com/weddingsvibe\",\"https://linkedin.com\",\"https://youtube.com\",\"https://pinterest.com\"]}"}}],["$","$L4",null,{"children":["$","$L5",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L6",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","section",null,{"className":"sec","children":["$","div",null,{"className":"wrap center","children":[["$","p",null,{"className":"eyebrow","children":"404 · PAGE NOT FOUND"}],["$","h1",null,{"className":"h2","children":"This page wandered off."}],["$","p",null,{"className":"sub","children":"Let’s find your way back to a beautiful beginning."}],["$","$L7",null,{"className":"btn","href":"/","children":"Back to weddingsvibe"}]]}]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]]}]}]]}],"p":true,"v":"$8"},"c":"$Q9"},"h":{"r":["$","$1","h",{"children":[null,["$","$L12",null,{"children":"$L13"}],["$","$L15",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$e",null,{"name":"Next.Metadata","children":"$L16"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":true,"v":"$17"}},"m":"$undefined","G":["$18",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1uec42u55d2ie.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$19","s":"$1a","a":"$@1b","l":"$undefined","p":"$undefined","d":"$undefined","b":"mCoMypNjACZUq3qcz_-Wu","u":"$@1c"}
a:C
1a:300
13:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
1d:I[27201,["$2","$3"],"IconMark"]
f:null
16:[["$","title","0",{"children":"Contact our wedding planners | Weddings Vibe"}],["$","meta","1",{"name":"description","content":"Tell weddingsvibe about your plans and we’ll help you find the right venues and teams."}],["$","meta","2",{"property":"og:title","content":"Contact our wedding planners | Weddings Vibe"}],["$","meta","3",{"property":"og:description","content":"Tell weddingsvibe about your plans and we’ll help you find the right venues and teams."}],["$","meta","4",{"property":"og:site_name","content":"Weddings Vibe"}],["$","meta","5",{"property":"og:locale","content":"en_IN"}],["$","meta","6",{"property":"og:type","content":"website"}],["$","meta","7",{"name":"twitter:card","content":"summary"}],["$","meta","8",{"name":"twitter:title","content":"Contact our wedding planners | Weddings Vibe"}],["$","meta","9",{"name":"twitter:description","content":"Tell weddingsvibe about your plans and we’ll help you find the right venues and teams."}],["$","link","10",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","link","11",{"rel":"icon","href":"/icon.png?icon.14cylqv-rudw7.png","sizes":"512x512","type":"image/png"}],["$","$L1d","12",{}]]
1a:C
17:C
19:C
10:C
8:C
1c:false
1b:null
