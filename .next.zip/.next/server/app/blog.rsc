#1:"$Sreact.fragment"
2:"/_next/static/chunks/3l5l8-x2c57rc.js"
3:"/_next/static/chunks/0mwf796fak0sn.js"
4:I[37895,["$2","$3"],"Shell"]
5:I[39756,["$2","$3"],"default"]
6:I[37457,["$2","$3"],"default"]
7:I[22016,["$2","$3"],""]
c:I[37895,["$2","$3"],"ImageBox"]
11:"ViewportBoundary"
12:I[97367,["$2","$3"],"$11"]
14:"MetadataBoundary"
15:I[97367,["$2","$3"],"$14"]
16:"$Sreact.suspense"
19:I[68027,["$2","$3"],"default",1]
:HL["/_next/static/chunks/1uec42u55d2ie.css","style"]
:HL["/_next/static/media/22a701959b157a82-s.p.2o7m9ogm38dql.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/6bafae418e8a1b08-s.p.3o_v2fun1jzxk.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/76e9fd951b869c7b-s.p.3bh2vc0w-r-ll.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/9d036f80216c14ee-s.p.3u4lli0-axodc.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/dd9dfc3601372168-s.p.43zbiuwnnoiok.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
8:X
a:X
10:X
b:[["children",{"s":"__PAGE__","h":514,"d":{"r":["$","$1","c",{"children":[["$","section",null,{"className":"sec","children":["$","div",null,{"className":"wrap","children":[["$","p",null,{"className":"eyebrow","children":"THE WEDDING JOURNAL"}],["$","h1",null,{"className":"h2","children":"Ideas for your next little step."}],["$","p",null,{"className":"sub","children":"Thoughtful guides to help you plan with a little more ease."}],["$","div",null,{"className":"grid venue-grid","children":[["$","$L7","choosing-your-wedding-venue",{"className":"card","href":"/blog/choosing-your-wedding-venue","children":[["$","$Lc",null,{"image":"im1.svg","alt":"A practical guide to choosing your wedding venue"}],["$","div",null,{"className":"cardbody","children":[["$","h2",null,{"children":"A practical guide to choosing your wedding venue"}],["$","p",null,{"children":"Thoughtful advice from our planning team to make your venue search easier."}],["$","strong",null,{"children":"Read the guide →"}]]}]]}],["$","$L7","wedding-budget-planning",{"className":"card","href":"/blog/wedding-budget-planning","children":[["$","$Lc",null,{"image":"im11.svg","alt":"How to plan a beautiful wedding on a budget"}],["$","div",null,{"className":"cardbody","children":[["$","h2",null,{"children":"How to plan a beautiful wedding on a budget"}],["$","p",null,{"children":"Thoughtful advice from our planning team to make your celebration budget easier."}],["$","strong",null,{"children":"Read the guide →"}]]}]]}],["$","$L7","personal-wedding-decor",{"className":"card","href":"/blog/personal-wedding-decor","children":[["$","$Lc",null,{"image":"im5.svg","alt":"Wedding decor ideas that feel personal"}],["$","div",null,{"className":"cardbody","children":[["$","h2",null,{"children":"Wedding decor ideas that feel personal"}],["$","p",null,{"children":"Thoughtful advice from our planning team to make your wedding decor easier."}],["$","strong",null,{"children":"Read the guide →"}]]}]]}],["$","$L7","wedding-photography-timeline",{"className":"card","href":"/blog/wedding-photography-timeline","children":[["$","$Lc",null,{"image":"im6.svg","alt":"Your wedding photography timeline, made simple"}],["$","div",null,{"className":"cardbody","children":[["$","h2",null,{"children":"Your wedding photography timeline, made simple"}],["$","p",null,{"children":"Thoughtful advice from our planning team to make your photo schedule easier."}],["$","strong",null,{"children":"Read the guide →"}]]}]]}],["$","$L7","destination-wedding-guide",{"className":"card","href":"/blog/destination-wedding-guide","children":[["$","$Lc",null,{"image":"im4.svg","alt":"A city-by-city destination wedding guide"}],"$Ld"]}],"$Le"]}]]}]}],null,"$Lf"]}],"p":true,"v":"$10"}}]]
9:[["children",{"s":"blog","h":514,"d":{"r":["$","$1","c",{"children":[null,["$","$L5",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L6",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":true,"v":"$a"},"c":"$Qb"}]]
18:X
1a:X
1b:X
0:{"P":null,"c":["","blog"],"q":"","i":false,"t":{"t":{"s":"","h":530,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1uec42u55d2ie.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/3l5l8-x2c57rc.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/0mwf796fak0sn.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"nbjMJa_variable mPCbcW_variable","children":["$","body",null,{"id":"top","children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Organization\",\"name\":\"Weddings Vibe\",\"url\":\"https://weddingsvibe.com\",\"email\":\"hello@weddingsvibe.com\",\"telephone\":\"+91 00000 00000\",\"sameAs\":[\"https://instagram.com/weddingsvibe\",\"https://linkedin.com\",\"https://youtube.com\",\"https://pinterest.com\"]}"}}],["$","$L4",null,{"children":["$","$L5",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L6",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","section",null,{"className":"sec","children":["$","div",null,{"className":"wrap center","children":[["$","p",null,{"className":"eyebrow","children":"404 · PAGE NOT FOUND"}],["$","h1",null,{"className":"h2","children":"This page wandered off."}],["$","p",null,{"className":"sub","children":"Let’s find your way back to a beautiful beginning."}],["$","$L7",null,{"className":"btn","href":"/","children":"Back to weddingsvibe"}]]}]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]]}]}]]}],"p":true,"v":"$8"},"c":"$Q9"},"h":{"r":["$","$1","h",{"children":[null,["$","$L12",null,{"children":"$L13"}],["$","$L15",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$16",null,{"name":"Next.Metadata","children":"$L17"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":true,"v":"$18"}},"m":"$undefined","G":["$19",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1uec42u55d2ie.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$1a","s":"$1b","a":"$@1c","l":"$undefined","p":"$undefined","d":"$undefined","b":"mCoMypNjACZUq3qcz_-Wu","u":"$@1d"}
1e:I[97367,["$2","$3"],"OutletBoundary"]
a:C
d:["$","div",null,{"className":"cardbody","children":[["$","h2",null,{"children":"A city-by-city destination wedding guide"}],["$","p",null,{"children":"Thoughtful advice from our planning team to make your destination plans easier."}],["$","strong",null,{"children":"Read the guide →"}]]}]
e:["$","$L7","questions-for-your-caterer",{"className":"card","href":"/blog/questions-for-your-caterer","children":[["$","$Lc",null,{"image":"im8.svg","alt":"Questions to ask before booking a caterer"}],["$","div",null,{"className":"cardbody","children":[["$","h2",null,{"children":"Questions to ask before booking a caterer"}],["$","p",null,{"children":"Thoughtful advice from our planning team to make your menu tasting easier."}],["$","strong",null,{"children":"Read the guide →"}]]}]]}]
f:["$","$L1e",null,{"children":["$","$16",null,{"name":"Next.MetadataOutlet","children":"$@1f"}]}]
1b:300
13:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
20:I[27201,["$2","$3"],"IconMark"]
17:[["$","title","0",{"children":"Wedding planning journal | Weddings Vibe"}],["$","meta","1",{"name":"description","content":"Wedding planning guides, ideas and practical advice from weddingsvibe."}],["$","meta","2",{"property":"og:title","content":"Wedding planning journal | Weddings Vibe"}],["$","meta","3",{"property":"og:description","content":"Wedding planning guides, ideas and practical advice from weddingsvibe."}],["$","meta","4",{"property":"og:site_name","content":"Weddings Vibe"}],["$","meta","5",{"property":"og:locale","content":"en_IN"}],["$","meta","6",{"property":"og:type","content":"website"}],["$","meta","7",{"name":"twitter:card","content":"summary"}],["$","meta","8",{"name":"twitter:title","content":"Wedding planning journal | Weddings Vibe"}],["$","meta","9",{"name":"twitter:description","content":"Wedding planning guides, ideas and practical advice from weddingsvibe."}],["$","link","10",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","link","11",{"rel":"icon","href":"/icon.png?icon.14cylqv-rudw7.png","sizes":"512x512","type":"image/png"}],["$","$L20","12",{}]]
1f:null
1b:C
18:C
1a:C
10:C
8:C
1d:false
1c:null
