1:"$Sreact.fragment"
2:"/_next/static/chunks/3l5l8-x2c57rc.js"
3:"/_next/static/chunks/0mwf796fak0sn.js"
4:I[37895,["$2","$3"],"Shell"]
5:I[39756,["$2","$3"],"default"]
6:I[37457,["$2","$3"],"default"]
7:I[22016,["$2","$3"],""]
f:I[37895,["$2","$3"],"ImageBox"]
15:"ViewportBoundary"
16:I[97367,["$2","$3"],"$15"]
17:"MetadataBoundary"
18:I[97367,["$2","$3"],"$17"]
19:"$Sreact.suspense"
1a:I[27201,["$2","$3"],"IconMark"]
:HL["/_next/static/chunks/1uec42u55d2ie.css","style"]
9:X
9:C
a:X
a:300
a:C
d:X
d:C
14:X
14:C
e:[["children",{"s":"__PAGE__","h":49314,"d":{"r":["$","$1","c",{"children":[["$","section",null,{"className":"sec","children":["$","div",null,{"className":"wrap","children":[["$","p",null,{"className":"eyebrow","children":"THE WEDDING JOURNAL"}],["$","h1",null,{"className":"h2","children":"Ideas for your next little step."}],["$","p",null,{"className":"sub","children":"Thoughtful guides to help you plan with a little more ease."}],["$","div",null,{"className":"grid venue-grid","children":[["$","$L7","choosing-your-wedding-venue",{"className":"card","href":"/blog/choosing-your-wedding-venue","children":[["$","$Lf",null,{"image":"im1.svg","alt":"A practical guide to choosing your wedding venue"}],["$","div",null,{"className":"cardbody","children":[["$","h2",null,{"children":"A practical guide to choosing your wedding venue"}],["$","p",null,{"children":"Thoughtful advice from our planning team to make your venue search easier."}],["$","strong",null,{"children":"Read the guide →"}]]}]]}],["$","$L7","wedding-budget-planning",{"className":"card","href":"/blog/wedding-budget-planning","children":[["$","$Lf",null,{"image":"im11.svg","alt":"How to plan a beautiful wedding on a budget"}],["$","div",null,{"className":"cardbody","children":[["$","h2",null,{"children":"How to plan a beautiful wedding on a budget"}],["$","p",null,{"children":"Thoughtful advice from our planning team to make your celebration budget easier."}],["$","strong",null,{"children":"Read the guide →"}]]}]]}],["$","$L7","personal-wedding-decor",{"className":"card","href":"/blog/personal-wedding-decor","children":[["$","$Lf",null,{"image":"im5.svg","alt":"Wedding decor ideas that feel personal"}],["$","div",null,{"className":"cardbody","children":[["$","h2",null,{"children":"Wedding decor ideas that feel personal"}],["$","p",null,{"children":"Thoughtful advice from our planning team to make your wedding decor easier."}],["$","strong",null,{"children":"Read the guide →"}]]}]]}],["$","$L7","wedding-photography-timeline",{"className":"card","href":"/blog/wedding-photography-timeline","children":[["$","$Lf",null,{"image":"im6.svg","alt":"Your wedding photography timeline, made simple"}],["$","div",null,{"className":"cardbody","children":[["$","h2",null,{"children":"Your wedding photography timeline, made simple"}],["$","p",null,{"children":"Thoughtful advice from our planning team to make your photo schedule easier."}],["$","strong",null,{"children":"Read the guide →"}]]}]]}],["$","$L7","destination-wedding-guide",{"className":"card","href":"/blog/destination-wedding-guide","children":[["$","$Lf",null,{"image":"im4.svg","alt":"A city-by-city destination wedding guide"}],["$","div",null,{"className":"cardbody","children":[["$","h2",null,{"children":"A city-by-city destination wedding guide"}],["$","p",null,{"children":"Thoughtful advice from our planning team to make your destination plans easier."}],"$L10"]}]]}],"$L11"]}]]}]}],null,"$L12"]}],"p":"$@13","v":"$14","s":"$a"}}]]
b:[["children",{"s":"blog","h":49250,"d":{"r":["$","$1","c",{"children":[null,["$","$L5",null,{"parallelRouterKey":"children","template":["$","$L6",null,{}]}]]}],"p":"$@c","v":"$d","s":"$a"},"c":"$Qe"}]]
1c:X
1c:C
1f:X
1f:C
0:{"t":{"t":{"s":"","h":49234,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1uec42u55d2ie.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/3l5l8-x2c57rc.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/0mwf796fak0sn.js","async":true}]],["$","html",null,{"lang":"en","className":"nbjMJa_variable mPCbcW_variable","children":["$","body",null,{"id":"top","children":[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Organization\",\"name\":\"Weddings Vibe\",\"url\":\"https://weddingsvibe.com\",\"email\":\"hello@weddingsvibe.com\",\"telephone\":\"+91 00000 00000\",\"sameAs\":[\"https://instagram.com/weddingsvibe\",\"https://linkedin.com\",\"https://youtube.com\",\"https://pinterest.com\"]}"}}],["$","$L4",null,{"children":["$","$L5",null,{"parallelRouterKey":"children","template":["$","$L6",null,{}],"notFound":[["$","section",null,{"className":"sec","children":["$","div",null,{"className":"wrap center","children":[["$","p",null,{"className":"eyebrow","children":"404 · PAGE NOT FOUND"}],["$","h1",null,{"className":"h2","children":"This page wandered off."}],["$","p",null,{"className":"sub","children":"Let’s find your way back to a beautiful beginning."}],["$","$L7",null,{"className":"btn","href":"/","children":"Back to weddingsvibe"}]]}]}],[]]}]}]]}]}]]}],"p":"$@8","v":"$9","s":"$a"},"c":"$Qb"},"h":{"r":["$","$1","h",{"children":[null,["$","$L16",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L18",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$19",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Wedding planning journal | Weddings Vibe"}],["$","meta","1",{"name":"description","content":"Wedding planning guides, ideas and practical advice from weddingsvibe."}],["$","meta","2",{"property":"og:title","content":"Wedding planning journal | Weddings Vibe"}],["$","meta","3",{"property":"og:description","content":"Wedding planning guides, ideas and practical advice from weddingsvibe."}],["$","meta","4",{"property":"og:site_name","content":"Weddings Vibe"}],["$","meta","5",{"property":"og:locale","content":"en_IN"}],["$","meta","6",{"property":"og:type","content":"website"}],["$","meta","7",{"name":"twitter:card","content":"summary"}],["$","meta","8",{"name":"twitter:title","content":"Wedding planning journal | Weddings Vibe"}],["$","meta","9",{"name":"twitter:description","content":"Wedding planning guides, ideas and practical advice from weddingsvibe."}],["$","link","10",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","link","11",{"rel":"icon","href":"/icon.png?icon.14cylqv-rudw7.png","sizes":"512x512","type":"image/png"}],["$","$L1a","12",{}]]}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":"$@1b","v":"$1c","s":"$a"}},"a":"$@1d","u":"$@1e","b":"mCoMypNjACZUq3qcz_-Wu","r":"$1f"}
20:I[97367,["$2","$3"],"OutletBoundary"]
10:["$","strong",null,{"children":"Read the guide →"}]
11:["$","$L7","questions-for-your-caterer",{"className":"card","href":"/blog/questions-for-your-caterer","children":[["$","$Lf",null,{"image":"im8.svg","alt":"Questions to ask before booking a caterer"}],["$","div",null,{"className":"cardbody","children":[["$","h2",null,{"children":"Questions to ask before booking a caterer"}],["$","p",null,{"children":"Thoughtful advice from our planning team to make your menu tasting easier."}],["$","strong",null,{"children":"Read the guide →"}]]}]]}]
12:["$","$L20",null,{"children":["$","$19",null,{"name":"Next.MetadataOutlet","children":"$@21"}]}]
1e:false
21:null
1d:null
c:"$undefined"
8:"$undefined"
1b:"$undefined"
13:"$undefined"
